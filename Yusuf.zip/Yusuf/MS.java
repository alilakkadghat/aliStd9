import java.util.*;
class MS
{
    public static void main()
    {
        int c=0;
        Scanner ob=new Scanner(System.in);
        System.out.println("enter a no");
        int n=ob.nextInt();
        System.out.println("choose an Alphabet between A,B");
        System.out.println("Type A if you want to find is your no even or odd");
        System.out.println("Type b if you want to find is your no prime or not a prime number");
        char ch =ob.next().charAt(0);
        System.out.println("Enter the no of times you want to rapeat the process");
        int m=ob.nextInt();
        for(int i=1;i<=m;i++)
        {
        switch(ch)
        {
        case 'a':
        case 'A':
        if(n%2==0)
        System.out.println(n+" is a even Number");
        else
        System.out.println(n+" is a odd Number");
        break;
        case 'B':
        case 'b':
                for( i=1;i<=n;i++)
        {
            if((n%i)==0)                    
                c++;
        }
        if(c==2)
            System.out.println(n+"  is a prime number");
        else
            System.out.println(n+"  is not a prime number");
            break;
            default:
            System.out.println("Error!!!!!");
        }
    }
}
}



        