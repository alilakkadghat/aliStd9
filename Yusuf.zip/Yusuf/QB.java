import java.util.*;
class QB
{

    public static void sum (int p,int c,int b)
    {
        int s=(p+c+b);
        System.out.println(s);
        double q=s/3;
        System.out.println("Science marks ="+q);
    }
    public static void sum(int p,int c)
    {
       
        int s=(p+c);
        System.out.println(s);
        double q=s/2;
        System.out.println("Social studies marks ="+q);
}
    public static void main()
    {
    
        sum(8,9,88);
        sum(99,23);
        
    }
}