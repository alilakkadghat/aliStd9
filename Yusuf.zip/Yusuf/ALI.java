class ALI  
{
 public static void main(int s,String z) 
{
    double bill=0;
    if (s >=0 && s <=100)
    {
            bill=s*1;
     }    
     else if(s >=101 && s <=200)
     {
         bill=s*1+((s-100)*2);
        }
      else if(s >=201 && s <=300)
     {
         bill=s*1+s*2+((s-200)*3);
        }
         else if(s >=301 && s <=400)
     {
         bill=s*1+s*2+s*3+((s-300)*4);
        }
       else
       {
         bill=s*1+s*2+s*3+s*4+((s-400)*5);
        }
         System.out.println("your salary="+s+"\n"+"your name="+z);
         //   System.out.println("your name="+z);
       // System.out.println("your bill="+bill);
    }
}
        
       
        