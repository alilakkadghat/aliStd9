
import java.util.*;
 class uni
{
    public static  void main()
    {
      Scanner ob =  new  Scanner(System.in);
      System.out.println("enter 1 to see unicode of alpha \n");
      System.out.println("enter 2 to see unicode of number\n ");
      System.out.println("enter 3 to see unicode of A\n ");
      System.out.println("enter 4 to see unicode of differnt language\n ");
       int q=ob.nextInt();
        switch(q)
         {
         case 1:
         number();
         break;
         case 2:
         character();
         break;
         case 3:
         mass();
         break;
         case 4:
         looping();
         break;
         default:
          System.out.println("Program not found ");
       }
    }
    private static  void number()
    {

        Scanner ob =  new  Scanner(System.in);
        System.out.println("enter a character ");
        char s=ob.next().charAt(0);
        int c=(int)s;
        System.out.println(c);
        
    }
     private static  void character()
    {
       Scanner ob =  new  Scanner(System.in);
        System.out.println("enter a number ");
        int s=ob.nextInt();
        char c=(char)s;
       
        System.out.println(c);
    }
    
    private static  void mass()
    {
       char ch1 = 'A';
       char ch2 = 65;
       char ch3 = '\101';
       char ch4 = '\u0041';
       System.out.println("ch1 : "+ch1);
       System.out.println("ch2 : "+ch2);
       System.out.println("ch3 : "+ch3);
       System.out.println("ch4 : "+ch4);
    }
     private static  void looping()
    {
    for (int i = 0; i <= 5535; i++) {
    char unicode = (char) i;
     System.out.print(unicode);
   }   
    }
}
  /*
   * 65535// DO NOT USE CRAHING WARNING!!!
   */