
class simple_test
{
  private static void mass()
{
     System.out.println("welcome");
    }
public static void main(int n)
{
        System.out.println("Thank you");
       simple_test.mass();
       double a=(double)Math.sqrt(n);
       System.out.println(a);
        int b=(int)Math.sqrt(n);
       System.out.println(b);
    }
}
