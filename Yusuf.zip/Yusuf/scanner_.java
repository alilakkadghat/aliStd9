import java.util.*;
class scanner_
{
    public static void main(int b)
    {
      Scanner obj =new Scanner(System.in);
  int a;
  a=obj.nextInt();
  int sum=a+b;
  double x=sum/0.20;
  System.out.println(sum);
   System.out.println(x);
}
}

  