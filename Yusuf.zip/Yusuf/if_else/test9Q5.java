
package if_else;
import java.util.*;
class test9Q5
{
    public static void main()
    {
    Scanner sc=new Scanner(System.in);
      System.out.println("Enter your name");
     String a =sc.next();
      System.out.println("Enter your pan number");
     String b =sc.next();
    System.out.println("Enter income");
    int n=sc.nextInt();
    double tax;
   if(n>=0 && n<=100000)
   tax=0;
   else if(n>100000 && n<=150000)
   tax=0.1*(n-100000);
   else if(n>150000 && n<=250000)
   tax=5000+0.2*(n-150000);
   else
   tax=25000+0.3*(n-250000);
   double ni=n-tax;
   System.out.println("Name:"+a);
   System.out.println("Pan No:"+b);
   System.out.println("Income:"+n);
   System.out.println("tax:"+tax);
   System.out.println("Net Income:"+ni);
}
}

