package if_else;
class salary_2
{/*enter your salary and name*/
   public static void main(int s,String a)
{
    
    // tax= (s>=0&&s<=5000)?z*0.5:(s>=5000 && s<=1000)?z*0.75:s*0.10;
   double tax=0;
  if (s>=0 && s<=5000)
  tax=0;
  else if(s>=5000 && s<=10000)
  tax=0.05*s;
  else if(s>=10000 && s<=25000)
  tax=0.075*s;
  else if (s>=25000 && s<=50000)
  tax=0.10*s;
  //else
  //tax=0.40*s;
  System.out.println("your Name="     +a);
  System.out.println("your salary ="    +s);
  System.out.println("tax amount="    +tax);
  double ns =(s-tax);
  System.out.println("net salary="    +ns);
}
}
 