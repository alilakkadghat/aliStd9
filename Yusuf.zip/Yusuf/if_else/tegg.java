package if_else;
import java.util.*;
class tegg
{/*enter the no of call*/
    public static void main()
    {
   Scanner sc=new Scanner (System.in);
     System.out.println("Enter the no calls");
     int z=sc.nextInt();
     double bill=0;
    if(z>=0 && z<=100)
     bill=z*10;
     else
     bill=z*20;
    System.out.println("Your bill ="+bill);
    tegg.mass();
}
  private static void mass()
    {
     Scanner sc=new Scanner (System.in);
     System.out.println("Enter the no calls");
     int z=sc.nextInt();
     double bill=0;
     bill= (z>=0&&z<=100)?z*10:z*20;
     System.out.println("Your bill ="+bill);
    }
}
