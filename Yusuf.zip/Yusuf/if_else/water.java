
/*Write a program to accept water usage in liters from the user and print the
bill amount on the screen based on the following conditions.
Water usage(liters) Amount(Rs.)
Upton 200                           80
Above 200 but up to 400             200
Above 400 but up to 600            500
Above 600 but up to 1000            1500
Above 1000                         5000*/
package if_else;
import java.util.*;
class water
{
    public static void main()
    {
        Scanner ob=new Scanner(System.in);
        System.out.println("Enter your water usage");
        int a=ob.nextInt();
        int amt=0;
        if(a<=200)
        amt=80;
        else if (a>=200 && a<=400)
        amt=200;
        else if (a>=400 && a<=600)
        amt=500;
        else if (a>=600 && a<=1000)
        amt=1500;
        else if (a>=1000 )
        amt=5000;
          System.out.println("AMOUNT="+amt);
        }
    }