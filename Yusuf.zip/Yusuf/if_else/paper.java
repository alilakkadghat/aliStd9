/*
Write a program to accept name of customer and number of units consumed
and calculate the bill as per following tariff:
Number of Units Rate per Unit
First 100 Units Rs.2.00
Next 200 Units Rs.3.00
Above 300 Units Rs.5.00
Finally print the bill with details as follows:
Name of Customer …………………..
Number of Units Consumed …………………..
Bill Amount ………………….*/
package if_else;
import java.util.*;
class paper
{
public static void main()
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter Name of customer ");
String n =sc.nextLine();
System.out.println("Enter Units Consumed ");
int units=sc.nextInt();
double bill;
if(units>0 && units<=100)
{
bill=units*2;
}
else if(units>100 && units<=300)
{
bill=(100*2)+((units-100)*3);
}
else
{
bill=(100*2)+(200*3)+((units-300)*5);
}
System.out.println("Name of Customer "+n);
System.out.println("Number of Units Consumed "+units);
System.out.println("Bill Amount "+bill);
}
}