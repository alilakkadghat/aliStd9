package if_else;
/*
 * Write a program to input number of kilometres travelled by a tourist and print
the fare amount on the screen based on the following conditions.

Distant travelled Rate per Kilometre
For first kilometre (Rs. 20 is fixed)
Plus next 10 Km 5 per km
Plus next 20 Km 8 per km
Above 31 km 10 per km
 */
import java.util.*;
class test7_q4
{
    public static void main()
    {
        Scanner ob=new Scanner(System.in);   
        System.out.println("Enter the number of kilometers traveled");
        int k=ob.nextInt();
        int amt=0;
        if(k==1)
        amt=20*k;
        else if (k>1 && k<=11)
        amt=(20*1)+(k-1)*5;
        else if (k>10 && k<=21)
        amt=(20*1)+(10*5)+(k-10)*8;
     else
     amt=(20*1)+(10*5)+(20*8)+(k-20)*10;
          System.out.println("fare amount="+amt);

        }
    }