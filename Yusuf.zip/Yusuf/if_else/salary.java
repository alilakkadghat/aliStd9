package if_else;
class salary
{/*enter the no of units*/
 public static void main(int unit,String a)
{
 double bill =0;  
if (unit>=0 && unit<=100)
{
   double rate = 1.20; 
   bill = unit*rate;
  System.out.println("Rate is Rs="+rate);
}
else if (unit>=101 && unit<=250)
{
  double rate = 2.50;
   bill = unit*rate;
   System.out.println("Rate is Rs="+rate);
}
else if (unit>=251 && unit<=500)
{
  double rate = 5.0;
   bill = unit*rate;
   System.out.println("Rate is Rs="+rate);
}
else 
{
  double rate = 8.0;
   bill = unit*rate;
  System.out.println("Rate  is Rs="+rate);
}
System.out.println("your bill is="+bill);
System.out.println("your name"+a);
System.out.println("Thank you");
}
}