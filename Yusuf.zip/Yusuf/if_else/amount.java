package if_else;
import java.util.*;
class amount
{
    public static void main()
    {
        double A,r;
        Scanner obj=new Scanner(System.in);
        System.out.println("Enetr your name");
        String q =obj.next();
        System.out.println("Enetr teh principle amount");
        int p=obj.nextInt();
        System.out.println("Enetr number of years");
        int n=obj.nextInt();
        if(n<1)
        r=9;
        else if(n>=1 && n<=3)
        r=9.25;
        else if(n>3 && n<=5)
        r=9.5;
        else
        r=9.25;
        A=p*(Math.pow((1+r/100),n));
        System.out.println(" Name;"+q);
        System.out.println("Accumualated amount:"+A);
    }
}