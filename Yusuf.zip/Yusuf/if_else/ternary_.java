package if_else;
import java.util.*;
class ternary_ 
{/*enter the no of call*/
    public static void main()
    {
    /*double bill=0;
    if(z>=0 && z<=100)
     bill=z*0.10;
     else if(z>=101 && z<=200)
     bill=z*0.20;& z<=300)
     bill=z*0.30;
     else if(z>=201 &
     else if (z>=301 && z<=400)
     bill=0.10*100+0.20*100+0.30*100+((z-400)*0.40);
     else
     bill=0;
     System.out.println("Your bill ="+bill);
    /*bill= (z>=0&&z<=100)?z*0.10:(z>=101 && z<=200)?z*0.20:0;
     System.out.println("Your bill ="+bill);*/
     Scanner sc=new Scanner (System.in);
     System.out.println("Enter the no calls");
     int z=sc.nextInt();
     double bill;
     bill= (z>=0&&z<=100)?z*0.10:(z>=101 && z<=200)?z*0.20:0;
     System.out.println("Your bill ="+bill);
     
    }
}