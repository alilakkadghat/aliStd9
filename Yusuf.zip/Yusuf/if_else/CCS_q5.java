
package if_else;
import java.util.*;
class CCS_q5
{
    public static void main()
    {
    Scanner sc=new Scanner(System.in);
      System.out.println("Enter your name");
     String a =sc.next();
      System.out.println("Enter your mobile number");
     String b =sc.next();
    System.out.println("Enter no.of days stayed");
    int n=sc.nextInt();
    double bill;
   if(n>=0 && n<=10)
   bill=1000*n;
   else if(n>10 && n<=15)
   bill=10*1000+(n-10)*1500;
   else if(n>15 && n<=20)
   bill=10*1000+5*1500+(n-15)*2000;
   else
   bill=10*1000+5*1500+5*2000+(n-20)*2500;
   double ni=bill*0.025;
   System.out.println("Name:"+a);
   System.out.println("Pan No:"+b);
   System.out.println("days stayed:"+n);
   System.out.println("bill:"+ni);
}
}

