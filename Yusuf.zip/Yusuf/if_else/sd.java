package if_else;
import java.util.*;
class sd
{
    public static void main()
    {
        Scanner ob=new Scanner(System.in);   
        System.out.println("Enter your name");
        String nm=ob.nextLine();
        System.out.println("Enter your water usage");
        int a=ob.nextInt();
        int amt=0;
        if(a<=100)
        amt=1*a;
        else if (a>=100 && a<=200)
        amt=(100*1)+(a-100)*2;
        else if (a>=200 && a<=300)
        amt=(100*1)+(100*2)+(a-200)*3;
     else
     amt=0;
          System.out.println("AMOUNT="+amt);
             System.out.println("Name ="+nm);
        }
    }