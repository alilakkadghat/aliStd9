package if_else;
class call
{/*enter the no of calls*/
 public static void main(int call)
{
 int bill =0;  
if (call>=0 && call<=100)
{
   int rate = 1; 
   bill = call*rate;
  System.out.println("Rate per call is Rs="+rate);
}
else if (call>=101 && call<=200)
{
  int rate = 2;
   bill = call*rate;
   System.out.println("Rate per call is Rs="+rate);
}
else if (call>=201 && call<=300)
{
  int rate = 3;
   bill = call*rate;
   System.out.println("Rate per call is Rs="+rate);
}
else if (call>=301 && call<=400)
{
  int rate = 4;
   bill = call*rate;
   System.out.println("Rate per call is Rs="+rate);
}
else 
{
  int rate = 5;
   bill = call*rate;
  System.out.println("Rate per call is Rs="+rate);
}
System.out.println("your bill is="+bill);
System.out.println("Thank you");
}
}



