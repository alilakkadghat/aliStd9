package modulus;
import java.util.*;
class factorial//not in this year syllabus
{
    public static void main()
    {
        Scanner sc=new Scanner (System.in);
System.out.println("Enter an Integer number:");
int n=sc.nextInt();
int d,c=n,s=0,x;
while(n!=0)
{
 d =n%10;
 n=n/10;
 x=1;
for(int i=1;i<=d;i++)
{
x=x*i;
}
s=s+x;
}
if(s==c)
System.out.println("special number");
else
System.out.println(" not special number");
}
}
/*
 * Write a program to input a number and print whether the number is a special
number or not. (A number is said to be a special number, if the sum of the
factorial of the digits of the number is same as the original number).

Example: 145 is a special number, because 1!+4!+5! = 1+24+120=145
(Where ‘!’ stands for factorial of the number and the factorial value of a
number is the product of all integers from 1 to that number, example
5!=1*2*3*4*5=120).
 */