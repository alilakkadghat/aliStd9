package modulus;
import java.util.*;
class buzz
{
    public static void main()
    { 
        Scanner ob =new Scanner(System.in);
         System.out.println("Enter 1 to find Buzz number\nEnter 2 to find GCD");
        int p=ob.nextInt();
        switch(p){
            case 1:
        Scanner obj =new Scanner(System.in);
         System.out.println("Enter a number");
        int n=obj.nextInt();
        if(n%7==0||n%10==7)
        
            System.out.println(n+" Is a Buzz Number");
            else
            System.out.println(n+" Is Not a Buzz number");
            break;
            case 2:
       
            Scanner sc=new Scanner (System.in);
       System.out.println("Enter the 1 st number\n"+"Enter 2nd number");
       int a=sc.nextInt();
        int b=sc.nextInt();
        int d;
      if(a>b)//144,10
      {
        while(b!=0)
       {
          d=a%b;//4
           a=b;//a=10,4
           b=d;//b=4
               
        }
           System.out.println(a+"gcd");
       }
      else
      {
      while(a!=0)
      {
          d=b%a;
           b=a;
           a=d;
        }
          System.out.println(b+"gcd");
    }
   
         break;
       default:
             System.out.println("Program not found");
    }
 }
}
/*
 * Write a menu driven program to accept a number from the user and
check whether it is a 'BUZZ' number or to accept any two numbers and print
the 'GCD' of them.
(a) A BUZZ number is the number which either ends with 7 or divisible by
7.
(b) GCD (Greatest Common Divisor) of two integers is calculated by
continued division method. Divide the larger number by the smaller; the
remainder then divides the previous divisor. The process is repeated till the
remainder is zero. The divisor then results the GCD.
 */