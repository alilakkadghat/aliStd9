package modulus;
import java.util.*;
class M_E
{
    public static void main()
    {
        Scanner sc =new Scanner(System.in);
         System.out.println("Enter a no");
         int a=sc.nextInt();
         int i,c=0;
         for(i=1;i<=a;i++)
         {
             if(a%i==0)
            c=c+1;
            }
            if(c==2)
             System.out.println(a+" is prime no");
             else
              System.out.println(a+"not a prime no");
        }
    }