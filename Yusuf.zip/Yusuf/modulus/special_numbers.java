package modulus;
import java.util.Date;
import java.text.*;
import java.util.*;
class special_numbers
{
    private static void mass()
    {
        System.out.println("program not found!!!!!");
        
    }
    private static void all()
    {
       all_run.main();
       whil3.main();
       palindrome.main();
       Niven.main();
       sum_product.main();
       armstrong.main();
       neon.main();
       Tech.main();
       spy.main();
       ICSE_Q5_2014.main();
       ICSE_Q9_2013.main();
       NUM_NaME.main();
       auto.main();
       while_fabocase.main();
       pal_perfect.main();
       small_large.main();
       buzz.main();
       prime_palindrome.main();
       ISBN_num.main();
       co_prime.main();
       successor.main();
       sunny_number.main();
       disarium.main();
    }

    public static void main()
    { 
         Date date =new Date();
         System.out.print("the file was Opened at\n");
            System.out.println(date.toString());
            //SimpleDateFormat sdf=new SimpleDateFormat("E yyyy/MM/dd  HH-mm-ss");
           // System.out.println(sdf.format(date));
            
        Scanner sc =new Scanner(System.in);
        System.out.println("\n\tTO RUN ALL PROGRAM ENTER 100\n");
         System.out.println(" To run all_run    Enter a  number 1");
        System.out.println("  To run whil3      Enter a  number 2 ");
        System.out.println("  To run palindrome Enter a  number 3");
        System.out.println("  To run Niven      Enter a  number 4");
        System.out.println("  To run sum_product Enter a  number 5");
        System.out.println("  To run  armstrong Enter a  number 6");
        System.out.println("  To run neon       Enter a  number 7");
        System.out.println("  To run Tech       Enter a  number 8");
        System.out.println("  To run spy        Enter a  number 9");
        System.out.println("  To run Q5_2014    Enter a  number 10"); 
        System.out.println("  To run Q9_2013    Enter a  number 11"); 
        System.out.println("  To run NUM_NaME   Enter a  number 12");
        System.out.println("  To run  auto      Enter a  number 13");
        System.out.println("  To run while_fabo  Enter a  number 14");
        System.out.println("  To run pal_perfect  Enter a  number 15");
        System.out.println("  To run small_large  Enter a  number 16");
        System.out.println("  To run buzz        Enter a  number 17");
        System.out.println("  To run prime_palindrome   Enter a  number 18");
        System.out.println("  To run ISBN_num     Enter a  number 19");
         System.out.println(" To run co_prime    Enter a  number 20");
         System.out.println(" To run successor   Enter a  number 21");
         System.out.println(" To run sunny_number   Enter a  number 22");
         System.out.println(" To run disarium   Enter a  number 23");
         int a=sc.nextInt();
   
        switch(a)
        {
      case 1:
    all_run.main();
      break;
      case 2:
     whil3.main();
     break;
     case 3:
     palindrome.main();
      break;
      case 4:
     Niven.main();
      break;
      case 5:
     sum_product.main();
      break;
      case 6:
     armstrong.main();
      break;
      case 7:
      neon.main();
      break;
      case 8:
     Tech.main();
      break;
      case 9:
     spy.main();
      break;
      case 10:
    ICSE_Q5_2014.main();
      break;
      case 11:
    ICSE_Q9_2013.main();
      break;
       case 12:
    NUM_NaME.main();
      break;
      case 13:
    auto.main();
      break;
      case 14:
     while_fabocase.main();
      break;
      case 15:
     pal_perfect.main();
      break;
      case 16:
     small_large.main();
      break;
       case 17:
     buzz.main();
      break;
      case 18:
       prime_palindrome.main();
      break;
        case 19:
      ISBN_num.main();
      break;
      case 20:
      co_prime.main();
      break;
      case 21:
      successor.main();
      break;
       case 22:
    sunny_number.main();
      break;
      case 23:
    disarium.main();
      break;
      case 100:
      special_numbers.all();
      default:
        special_numbers.mass();
    }
    }
}