package modulus;
import java.util.*;
class GCD 
{
    public static void main()
    {
              Scanner ob =new Scanner(System.in);
         System.out.println("Enter 1st number");
        int q=ob.nextInt();
         System.out.println("Enter 2nd number");
        int w=ob.nextInt();
        while(q!=w)
        {
           if(q>w)
           q=q-w;
           else
           w=w-q;
        }
                 System.out.println("GCD="+w);
                }
            }  