package modulus;
import java.util.*;
class  sunny_number
{
    public static void main()
    {
       Scanner sc =new Scanner(System.in);
       System.out.println("Enter a number");
       int n =sc.nextInt();
      
        if((Math.sqrt(n+1)%1.0)==0.0)//2 4
         System.out.println("sunny number");
           else
        System.out.println("not sunny number");
    }
    }
/*
 * int x=Math.sqrt(n+1);
 * int rem=x-(int)x;
 * if(rem==0.0);
 */


 
    