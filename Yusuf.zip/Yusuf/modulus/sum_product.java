package modulus;
import java.util.*;
class  sum_product
{
    public static void main()
    {
       Scanner sc =new Scanner(System.in);
       System.out.println("Enter a number");
       int n =sc.nextInt();
        int even=1,odd=0;
    int s;
        while(n>0)
    {
        s = n%10;
         n= n/10;
        if(s%2==0)
            even = even*s;
        else
        
            odd = odd+s;
    }
    System.out.println("sum of odd numbers  "+odd);
       System.out.println("product of even numbers  "+even);
    }
}


 
    