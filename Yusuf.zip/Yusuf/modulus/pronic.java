package modulus;
import java.util.*;
class pronic
{

public static void main(int n)

{
int s=0;
boolean c=false;
for(int i=1;i<n;i++)
{
   s=i*(i+1);
   if(s==n)
   {
System.out.println(n+"is a pronic no ");
c=true;
break;
}
}
if(c==false)
System.out.println(n+"is a pronic no ");
}
}