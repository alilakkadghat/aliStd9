package modulus;
import java.util.*;
class M_B
{
    public static void main()
    {
        Scanner sc =new Scanner(System.in);
         System.out.println("Enter a no");
         int a=sc.nextInt();
         if (a%8==0)
          System.out.println(a+"divisible by 8");
          else
           System.out.println(a + "_____not divisible by 8");
        }
    }