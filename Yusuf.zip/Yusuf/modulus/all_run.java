package modulus;
import java.util.*;
class all_run 
{
    private static void mass()
    {
        System.out.println("program not found!!!!!");
        
    }
    private static void all()
    {
       M_A.main();
       M_B.main();
       M_C.main();
       M_D.main();
       M_E.main();
       M_F.main();
       hcf.main();
       lcm_1.main();
       lcm_2.main();
       M_I.main();
       leap_year1.main();
       leap_year2.main();
    }

    public static void main()
    { 
          Scanner sc =new Scanner(System.in);
          System.out.println("\n\tTO RUN ALL PROGRAM ENTER 100\n");
        System.out.println("  To run M_A        Enter a  number 1 ");
        System.out.println("  To run M_B        Enter a  number 2");
        System.out.println("  To run M_C        Enter a  number 3");
        System.out.println("  To run M_D        Enter a  number 4");
        System.out.println("  To run M_E        Enter a  number 5");
        System.out.println("  To run M_F        Enter a  number 6");
        System.out.println("  To run hcf        Enter a  number 7");
        System.out.println("  To run lcm_1      Enter a  number 8");
        System.out.println("  To run lcm_2      Enter a  number 9");
        System.out.println("  To run M_I        Enter a  number 10"); 
        System.out.println("  To run leap_year_1      Enter a  number 11"); 
        System.out.println("  To run  leap_year_2     Enter a  number 12");
      
         int a=sc.nextInt();
   
        switch(a)
        {
      case 1:
     M_A.main();
     break;
     case 2:
     M_B.main();
      break;
      case 3:
     M_C.main();
      break;
      case 4:
     M_D.main();
      break;
      case 5:
     M_E.main();
      break;
      case 6:
     M_F.main();
      break;
      case 7:
     hcf.main();
      break;
      case 8:
     lcm_1.main();
      break;
      case 9:
     lcm_2.main();
      break;
      case 10:
     M_I.main();
      break;
      case 11:
     leap_year1.main();
      break;
      case 12:
     leap_year2.main();
      break;
      case 100:
      all_run.all();
      default:
      all_run.mass();
    }
    }
}