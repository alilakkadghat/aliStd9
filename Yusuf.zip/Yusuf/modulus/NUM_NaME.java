package modulus;
import java.util.*;
  class  NUM_NaME
 {
     public static void main() {
       Scanner sc =new Scanner(System.in);
       System.out.println("Enter a number");
       int n =sc.nextInt();
        int d,s=0;
         
        while(n>0)
        {
        d= n%10;
         n= n/10;
         s=(s*10)+d;
        }
        n=s;
        System.out.println(n+"number =");
        System.out.println(s+"number o");
        while(n>0)
       {
        d= n%10;
         n= n/10;
        if(d==0)
              System.out.print("ZERO\t");
        else if(d==1) 
           System.out.print("ONE\t");
          else if(d==2)
              System.out.print("TWO\t");
        else if(d==3) 
           System.out.print("THREE\t");
         else if(d==4)
              System.out.print("FOUR\t");
        else if(d==5) 
           System.out.print("FIVE\t");
           else if(d==6) 
           System.out.print("SIX\t");
          else if(d==7)
              System.out.print("SEVEN\t");
        else if(d==8) 
           System.out.print("EIGHT\t");
          else if(d==9)
           System.out.print("NINE\t");
      }
    }
  }
        
      

 
    