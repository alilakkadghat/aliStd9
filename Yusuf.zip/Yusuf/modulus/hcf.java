package modulus;
import java.util.*;
class hcf
{
    public static void main()
    { 
        Scanner sc =new Scanner(System.in);
         System.out.println("Enter a no");
         int a=sc.nextInt();
          System.out.println("Enter a second no");
         int b=sc.nextInt();
         int i,hcf=1;
         for(i=1;i<=a;i++)
         {
             if(a%i==0 && b%i==0)//8,16
           {hcf=i;
               
            }
        }
         System.out.println("hcf="+hcf);
    }
}