package modulus;
import java.util.*;
class  palindrome
{
    public static void main()
    {
       Scanner sc =new Scanner(System.in);
       System.out.println("Enter a number");
       int n =sc.nextInt();
        int a,s=0;
         int b=n;//copy
        while(n>0)
    {
        a= n%10;
         n= n/10;
         s=(s*10)+a;
        }
           System.out.println(s);
        if(b==s)
              System.out.println(b+"  is a   palindrome no");
        else
           System.out.println(b+"  is not a   palindrome no");
    }
}



 
    