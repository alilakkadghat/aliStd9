package modulus;
import java.util.*;
class leap_year2
{
    public static void main()
    {
   Scanner ob= new Scanner(System.in);
   System.out.println("enter from where you want to find leap year");
   int ss=ob.nextInt();
        for(int year=2020;year>=ss;year=year-4)
     {
    if((year%400 == 0) || ((year%100) != 0 && (year%4 == 0)))
            System.out.println(year+"is a leap year");
            else
               System.out.println(year+"is not a leap year");
            }
        }
        }