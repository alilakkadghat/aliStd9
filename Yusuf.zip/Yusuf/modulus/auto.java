 package modulus;
 import java.util.*;
class auto
{
    public static void main()
    {
        Scanner sc =new Scanner(System.in);
        System.out.println("Enter 1 to find prime\n \nEnter 2 to find the automorphic\n");
         int m=sc.nextInt();
         int i,c=0;
        switch(m)
        {
        case 1:
           System.out.println("Enter a no");
         int a=sc.nextInt();
         for(i=1;i<=a;i++)
      {
             if(a%i==0)
            c=c+1;
            }
            if(c==2)
      {
             System.out.println(a+" is a prime Number");
            }
             else
             {
              System.out.println(a+" is not a prime Number");
            }
          break;
           case 2:
            Scanner ob =new Scanner(System.in);
               System.out.println("Enter a no");
         int n=sc.nextInt();
              int copy=n,d,s=1;
              int sq=n*n;
              while(n!=0)
       {
                d=n%10;
               n=n/10;   
             s=s*10;
            }
            int auto=sq%s;
            if(copy==auto)
         System.out.println(auto+"\t is  a automorphic");
       else
           System.out.println(" is not automorphic");
        }
        }
        }
        /*
         * Write a menu driven program to accept a number and check and display
whether it is a prime number or not OR an automorphic number or not. (Use
switch-case statement)
a) Prime number: A number is said to be a prime number if it is divisible
only by 1 and itself and not by any other number.
Example: 3,5,7,11,13 etc.

b) Automorphic number: An automorphic number is the number which is
contained in the last digit(s) of its square.
Example 25 is an automorphic number as its square is 625 and 25 is
present as the last two digits.
         */
    
    