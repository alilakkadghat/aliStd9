 //2-4+6-8...-20=?
package modulus;
class M_I
{
    public static void main()
    {
     int i,c=0;
  for(i=2;i<=20;i=i+2)
  {
      
 if (i%4==0)
    c=c-i;  
    else
    c=c+i; 
          System.out.println(i);
    }
      System.out.println("thank you"+c);
    }
}
