package modulus;
import java.util.*;
class  successor
{
    public static void main()
    {
       Scanner sc =new Scanner(System.in);
       System.out.println("Enter a number");
       int n =sc.nextInt();
        int even=1,odd=0,c;
    int s;
        while(n>0)
    {//2745
        s = n%10;
         n= n/10;
        if(s%2==0)//2 4
        {
            c=1+s;
            even=even*c;
        }
    }
       System.out.println("product of even numbers  "+even);
    }
}


 
    