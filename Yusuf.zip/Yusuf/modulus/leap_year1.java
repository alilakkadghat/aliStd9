package modulus;
import java.util.*;
class leap_year1
{
    public static void main()
    {
        Scanner ob=new Scanner(System.in);
          System.out.println("Enter a year");
        int year=ob.nextInt();  
    if((year%400 == 0) || ((year%100) != 0 && (year%4 == 0)))
            System.out.println(year+"  is a leap year");
            else
               System.out.println(year+"  is not a leap year");
            
        }
        }