/*a number is said to be duck number if the digit zero is 
present in it. write a program to accept a number and check 
whether the number is duck number
*/package modulus;
import java.util.*;
class  duck
{
    public static void main()
    {
       Scanner sc =new Scanner(System.in);
       System.out.println("Enter a number");
       int n =sc.nextInt();
       int s;
        while(n>0)
    {
        s=n%10;
        n=n/10;
        if(s==0)
        {
            System.out.println("is a duck no  ");
        break;}
            
        else{
         System.out.println(" not duck no  ");
        }
    }
    }
}


 
    