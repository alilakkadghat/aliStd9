package modulus;
import java.util.*;
class spy
{

public static void main()

{
Scanner sc=new Scanner (System.in);
System.out.println("enter a number ");
int n=sc.nextInt();
int i=0,d,a=1;
int q=n;
while(n!=0)
{
d=n%10;//5
n=n/10;//30
i=i+d;
a=a*d;
}
if(a==i)
System.out.println(q+"   is a spy  Number ");
else
System.out.println(q+"   is a NOT spy  Number ");
}
}
/*
 * Write a program to accept a number and check and display whether it is a
spy number or not. (A number is spy if the sum of its digits equals the
product of its digit).
Example : 1124 Sum of digits = 1+1+2+4=8
Product of digits = 1x1x2x4=8
 */