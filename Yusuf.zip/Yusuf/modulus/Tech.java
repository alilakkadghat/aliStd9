package modulus;
import java.util.*;
class Tech

{

public static void main()

{
Scanner sc=new Scanner (System.in);

int i=1000,a,b,s,sq;
while(i<9999)
{
i=i+1;//3025
b=i%100;//25
a=i/100;//30

s=a+b;
sq=s*s;
if(sq==i)
System.out.println(i+"is a tech no ");

}
}
}
/*
 * A tech number has even number of digits. If the number is split into two equal
halves, then the square of sum of these halves is equal to the number itself.
Write a program to generate and print all four digits tech numbers.
Example:
Consider the number 3025
Square of sum of halves of 3025 = (30+25)2

= (55)2
= 3025 is a tech number
 */