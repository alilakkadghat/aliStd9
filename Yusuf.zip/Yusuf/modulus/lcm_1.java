package modulus;
import java.util.*;
class lcm_1
{
    public static void main()
    { 
        Scanner sc =new Scanner(System.in);
         System.out.println("Enter a no");
         int a=sc.nextInt();
          System.out.println("Enter a second no");
         int b=sc.nextInt();
         int i,hcf=1;
         for(i=1;i<=a;i++)
         {
             if(a%i==0 && b%i==0)
           {hcf=i;
            int lcm=(a*b)/hcf;
             System.out.println("LCM="+lcm);
            }
        }

    }
}