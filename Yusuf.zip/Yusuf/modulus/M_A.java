package modulus;
import java.util.*;
class M_A
{
    public static void main()
    {
        Scanner sc =new Scanner(System.in);
         System.out.println("Enter a no");
         int a=sc.nextInt();
         if (a%2==0)
          System.out.println(a+"is a even no");
          else
           System.out.println(a + "_____is a odd no");
        }
    }