package modulus;
import java.util.*;
class small_large
{
    public static void main()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter 1 to find the smallest \n\tOR\t\n Enter 2 to find the largest\n\tOR\t\nEnter 3 to run both");
        int m=sc.nextInt();
        switch(m){
      case 1:
      Scanner ob=new Scanner(System.in);
        System.out.println("Enter a number");
        int n=ob.nextInt();
      int s=9,d;
      while(n!=0)
      {
      d=n%10;
      n=n/10;
      s=Math.min(s,d);
    }
    System.out.println("The Smallest Digit is\t"+s);
    break;
    case 2:
    Scanner obj=new Scanner(System.in);
        System.out.println("Enter a number");
        int n1=obj.nextInt();
        int l=0,i;
        while(n1!=0)
        {
            i=n1%10;
            n1=n1/10;
            l=Math.max(l,i);
        }
         System.out.println("The Largest Digit is\t"+l);
    break;
    case 3:
    small_large.mass();
     break;
    default:
        System.out.println("Program Not found");
 }
   }
private static void mass()
{
   Scanner obj=new Scanner(System.in);
        System.out.println("Enter a number");
        int n2=obj.nextInt();
        int l=0,i,s=9;
        while(n2!=0)
        {
            i=n2%10;
            n2=n2/10;
            l=Math.max(l,i);
            s=Math.min(s,i);
        }
         System.out.println("The Largest Digit is\t"+l);
         System.out.println("The Smallest Digit is\t"+s);
}
}