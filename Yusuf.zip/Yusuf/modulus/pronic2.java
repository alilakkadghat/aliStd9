package modulus;
import java.util.*;
class pronic2
{

public static void main(int n)

{
int s=0;
for(int i=1;i<n;i++)
{
   s=i*(i+1);
   if(s==n)
   {
System.out.println(n+"   is a pronic no ");
System.exit(0);
}
}
System.out.println(n+ "  was not a pronic no ");
}
}
/*
 * Write a program to input a number and check and print whether it is a
Pronic number or not. (Pronic number is the number which is the product
of two consecutive integers)
Examples: 12 = 3 x 4
20 = 4 x 5
42 = 6 x 7
 */