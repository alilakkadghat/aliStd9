package modulus;
import java.util.*;
class ICSE_Q9_2013
{
    public static void main()
    {
        Scanner sc =new Scanner(System.in);
        System.out.println("Enter 1 to find composite number\n \nEnter 2 to find the smallest digit\n");
         int m=sc.nextInt();
         int i,c=0;
         switch(m)
         {
         case 1:
           System.out.println("Enter a no");
         int a=sc.nextInt();
         for(i=2;i<a;i++)
         {
             if(a%i==0)
            c=c+1;
            }
            if(c!=0){
             System.out.println(a+" is a composite Number");
            }
             else
             {
              System.out.println(a+" is not a composite Number");
            }
              break;
              case 2:
               System.out.println("Enter a no");
               int b=sc.nextInt();
                int small=9;
              while(b!=0)
              {
                  i=b%10;
                  b=b/10;
                 small=Math.min(i,small);
            }
            System.out.println(small+"   Is the Smallest Digit");
            break;
            default:
            System.out.println("Program Not found !!!");
        }
    }
}
/*
 * Using the switch statement, write a menu driven program:
(i) To check and display whether a number input by the user is a composite
number or not (A number is said to be a composite, if it has one or more than
one factor excluding 1 and the number itself).
Example: 4, 6, 8, 9 ...
(ii) To find the smallest digit of an integer that is input.
Sample Input : 6524
Sample Output: Smallest digit is 2
For an incorrect choice, an appropriate error message should be displayed.
 */
    