package modulus;
import java.util.*;
class  Niven
{
    public static void main()
    {
       Scanner sc =new Scanner(System.in);
       System.out.println("Enter a number");
       int n =sc.nextInt();
        int a,s=0;
         int b=n;
        while(n>0)
    {
        a= n%10;
         n= n/10;
         s=s+a;
        }
           System.out.println(s);
        if(b%s==0)
              System.out.println(b+"  is a   niven no");
        else
           System.out.println(b+"  is not a  niven no");
    }
}
/*
 * Write a program to accept a number and check and display whether it is a
niven number or not.
(Niven number is that which is divisible by the sum of its digits).
Example:126 1+2+6=9 126 is divisible by 9
 */


 
    