package modulus;
import java.util.*;
class ICSE_Q5_2014
{

public static void main()

{
Scanner sc=new Scanner (System.in);
System.out.println("enter a number ");
int n=sc.nextInt();
int i=0,d,a=1,u=0;
int q=n;
if(n<=9||n>99)
{
    System.out.println("NOT A SPECIAL NUMBER");
    System.exit(0);
}
    else
    {
while(n!=0)
{
d=n%10;//5
n=n/10;//30
i=i+d;
a=a*d;
u=a+i;
}
if(u==q)
System.out.println(q+"   is a special Number ");
else
System.out.println(q+"   is a not special Number ");
}
}
}
/*
 * A special two-digit number is such that when the sum of its digits is added
to the product of its digits, the result is equal to the original two-digit
number.
Example: Consider the number is 59.
Sum of digits = 5 + 9 = 14
Product of digits = 5 x 9 = 45
Sum of the sum of digits and product of digits = 14 + 45 = 59
Write a program to accept a two-digit number. Add the sum of its digits to
the product of its digits. If the value is equal to the number input, output
message “Special 2-digit number” otherwise, output the message “Not a
special 2-digit number”.
 */