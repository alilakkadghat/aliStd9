package modulus;
import java.util.*;
class M_C
{
    public static void main()
    {
        Scanner sc =new Scanner(System.in);
         System.out.println("Enter a no");
         int a=sc.nextInt();
         int i;
         for(i=1;i<=a;i++)
         {
             if(a%i==0)
             System.out.println(i+"are the factors");
            }
        }
    }