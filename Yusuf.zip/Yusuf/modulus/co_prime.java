package modulus;
import java.util.*;
class co_prime
{
    public static void main()
    { 
        Scanner sc =new Scanner(System.in);
         System.out.println("Enter a no");
         int a=sc.nextInt();
          System.out.println("Enter a second no");
         int b=sc.nextInt();
         int i,hcf=1;
         for(i=1;i<=a;i++)
         {
        if(a%i==0 && b%i==0)
        hcf=i;
       }
       if(hcf==1)
       {
            System.out.println(a+"  &  "+b+" are co prime");
     }
     else
     {
               System.out.println(a+"  &  "+b+" are not co prime");
        }
    }
}