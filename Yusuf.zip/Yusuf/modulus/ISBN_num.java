package modulus;
import java.util.*;
class ISBN_num 
{
    public static void main()
    {
        Scanner sc=new Scanner (System.in);
        System.out.println("Enter a number");
        int n=sc.nextInt();//1401601499
        int p,s,c=0,i,t,sum=0;
        p=n;
        s=n;
        while(p!=0)
        {
            p=p/10;
            c++;//10
        }
        if(c!=10)
        {
            System.out.println("Illegal ISBN Number");
             System.exit(0);
        }
        else
        {
            while(s!=0)
            {
                t=s%10;
                s=s/10;
                sum=sum+(t*c);
                c--;
            }
             
            if(sum%11==0)
              System.out.println(n+" Is A  legal ISBN NUMBER ");
                    else
                System.out.println(n+"  Is NOT A legal ISBN NUMBER ");
              }
}
}
 
/*
 * The International Standard Book Number (ISBN) is a unique numeric book
identifier which is printed on every book. The ISBN is based upon a 10-digit code.
The ISBN is legal if:
1 x digit1 + 2 x digit2 + 3 x digit3 + 4 x digit4 + 5 x digit5 + 6 x digit + 7 x digit7
+ 8 x digit8 + 9 x digit9 + l0 x digit10 is divisible by 11.
Example: For an ISBN 1401601499
Sum=l x l + 2x4 + 3x0 + 4x1 + 5x6 + 6x0 + 7x1 + 8x4 + 9x9 + 10x9 = 253 which
is divisible by 11.

 * Write a program to:
(i) Input the ISBN code as a 10-digit integer.
(ii) If the ISBN is not a 10-digit integer, output the message, "Illegal ISBN"
and terminate the program.
(iii) If the number is 10-digit, extract the digits of the number and compute
the sum as explained above.
If the sum is divisible by 11, output the message, "Legal ISBN". If the sum is
not divisible by 11, output the message, "Illegal ISBN". 

 */
        