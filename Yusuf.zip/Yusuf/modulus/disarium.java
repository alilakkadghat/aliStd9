package modulus;
import java.util.*;
class  disarium
{
    public static void main()
    {
       Scanner sc =new Scanner(System.in);
       System.out.println("Enter a number");
       int n =sc.nextInt();
        int sum=0,c=0;
         int n1=n;
         int p=n;
         int d;
        while(p!=0)//135
    {
        c++;//2
         p=p/10;
        }
       
        while(n1!=0)
        {
           d=n1%10;
           n1=n1/10;
           sum=sum+(int)Math.pow(d,c);
           c--;
         
    }
    if(n==sum)
     System.out.println(n+"  is a disarium number");
     else
      System.out.println(n+"  is not a disarium number");
}
}
//135 -> 1+9+125=135