package modulus;
import java.util.*;
class  neon
{
    public static void main()
    {
       Scanner sc =new Scanner(System.in);
       System.out.println("Enter a number");
       int n =sc.nextInt();
        int sq,s=0;
         int b=n;
         sq=n*n;
        while(sq>0)
    {
        s=s+sq%10;
         sq= sq/10;
   
        }
        if(b==s)
              System.out.println(b+"is a neon no");
        else
           System.out.println(b+"is not a neon no");
    }
}