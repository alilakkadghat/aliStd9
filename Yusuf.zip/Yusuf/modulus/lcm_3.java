package modulus;
import java.util.*;
class lcm_3
{
    public static void main()
    { 
        Scanner sc =new Scanner(System.in);
         System.out.println("Enter a no");
         int a=sc.nextInt();
          System.out.println("Enter a second no");
         int b=sc.nextInt();
         System.out.println("Enter a third no");
         int c=sc.nextInt();
         int i,lcm=1;
         for(i=1;i<=(a*b*c);i++)
         {
             if(i%a==0 && i%b==0 && i%c==0)
           {
               lcm=i;
               break;
            }
        }
         System.out.println("lcm="+lcm);
    }
}
