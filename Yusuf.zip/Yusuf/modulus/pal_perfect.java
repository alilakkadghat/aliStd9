package modulus;
import java.util.*;
class pal_perfect
{
 public static void main()
 {
       Scanner sc=new Scanner(System.in);
 System.out.println("Enter 1 to run palindrome Number\nEnter 2 to run perfect number");
   int m=sc.nextInt();
   switch(m)
   {
       case 1:
         Scanner ob=new Scanner(System.in);
        System.out.println("enter a number");
         int n=ob.nextInt();
         int d,s=0,nc=n;
        while(n!=0)
    {
        d=n%10;
        n=n/10;
        s=(s*10)+d;   
    }
     System.out.println(s);
    if(nc==s)
       System.out.println(nc+"\tis a   palindrome no");
        else
      System.out.println(nc+"\tis not a   palindrome no");
       break;
        case 2:
         Scanner obj=new Scanner(System.in);
         System.out.println("enter a number");
         int k=obj.nextInt();
         int i,c=0;
       for(i=1;i<k;i++)
         {
             if(k%i==0)
              c=c+i; 
            }
  if(c==k)
          System.out.println(k+"\tIS a Perfect Number");
              else
             System.out.println(k+"\tIS Not a Perfect Number");
             break;
             default:
              System.out.println("Program Not found");
      }
  }
 }
 /*
  * Write a menu driven class to accept a number from the user and check
whether it is a Palindrome or a Perfect number.
(a) Palindrome number - (a number is a Palindrome which when read
in reverse order is same as read in the right order)
Example: 11, 10 1,151 etc.

(b) Perfect number - (a number is called Perfect if it is equal to the sum
of its factors other than the number itself.)
Example: 6=1+2+3
  */
            
    
