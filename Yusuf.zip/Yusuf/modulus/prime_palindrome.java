package modulus;    
import java.util.*;
     class prime_palindrome
    {
     public static void main()
    {
        int i=1,n,n1,rev=0,dig,c=0;
        Scanner ob=new Scanner(System.in);
        System.out.println("enter a number");
        n=ob.nextInt();
        n1=n;
        while(i<=n)
        {
            if((n%i)==0)
            {
                c++;
            }
             i++;
        }
        while(n1!=0)
        {
            dig=n1%10;
            rev=(rev*10)+dig;
            n1=n1/10;
        }
        if((c==2)&&n==rev)
            System.out.println(n+"  is a prime palindrome number");
        else
            System.out.println(n+"  is not a  prime palindrome number");
    }
}
