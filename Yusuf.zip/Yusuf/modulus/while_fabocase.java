package modulus;
import java.util.*;
class while_fabocase
{
    public static void main()
    { 
        Scanner sc =new Scanner(System.in);
         System.out.println("Enter 1 to find fibonacci series\nEnter 2 to find the sum of digits");
        int p=sc.nextInt();
        switch(p){
            case 1:
        int i=1,a=0,b=1;
        System.out.println(a);
        System.out.println(b);
        int c=a+b;
        while(i<=8)
        {
            System.out.println(c);
           a=b;
           b=c;
           c=a+b;
           i++;
        }
        break;
        case 2:
        Scanner ob =new Scanner(System.in);
         System.out.println("Enter a number");
        int n=ob.nextInt();
        int d,l=0;
        while(n!=0)
        {
            d=n%10;
            n=n/10;
            l=l+d;
    }
       System.out.println("sum of the digits= "+l);
      break;
      default:
      System.out.println("Program Not Found");
   }
  }
}
/*
 * Using the switch statement, write a menu driven program to :
i) Generate and display the first 10 terms of the Fibonacci series
0,1,1,2,3,5.....
The first two Fibonacci numbers are 0 and 1, and each subsequent number
is the sum of the previous two.
ii) Find the sum of the digits of an integer that is input.
Sample Input : 15390
Sample Output : Sum of the digits=18
For an incorrect choice, an appropriate error message should be displayed.

 */

