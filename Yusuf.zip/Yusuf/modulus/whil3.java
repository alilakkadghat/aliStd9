package modulus;
import java.util.*;
class  whil3
{
    public static void main()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a no");
        int n=sc.nextInt();
        int d,s=1;
        
        while(n>0)//5
        { 
            d=n%10;
            s=s*d;
            System.out.println(d);
            n=n/10;
        }
        System.out.println("sum  "+s);
    }
}