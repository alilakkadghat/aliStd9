import java.util.*;
class Q_F
{/*enter the number of times you want to repeat the process*/
    public static void main(int h)
    {
        Scanner ob=new Scanner(System.in);
        for(int i=1;i<=h;i++)
        {
        System.out.println("Enter the larger numbers");
        int n=ob.nextInt();
          System.out.println("Enter the smaller numbers");
        int s=ob.nextInt();
         System.out.println("Enter 1 to add the No.");
         System.out.println("Enter 2 to subtract the No.");
         System.out.println("Enter 3 to multiply the No.");
         System.out.println("Enter 4 to divide the No.");
         int w =ob.nextInt();
         int q;
         double m;
      
        switch(w)
        {
        case 1:
         q=n+s;
        System.out.println("sum ="+q);
        break;
        case 2:
         q=n-s;
        System.out.println("difference ="+q);
        break;
        case 3:
         q=n*s;
        System.out.println("product ="+q);
        break;
        case 4:
         m=n/s;
        System.out.println("quotient ="+m);
        break;
        default:
        System.out.println("wrogn number");
    }
       }
   }
}
    