  package maths;
class loll
{
    public static void main()
    {
        int max=74;
        int min=51;
        int s;
        for(s=0;s<=100;s++)
        {
            double x=Math.random()* (max - min + 1) + min;
             long q=Math.round(x);//74-51+1+51
             System.out.println(q);
        }
    }
}

        