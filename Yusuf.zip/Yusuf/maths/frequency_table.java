package maths;
import java.util.*;
class frequency_table
 {
    public static void main()
   {
      long x=0;
      int c=0,s=0,r=0;
      
      Scanner sc=new Scanner(System.in);
       System.out.println("Enter The Number Of Students");
      int o=sc.nextInt();
       int i=1;
        while(i<=o)
     {
      x =Math.round(Math.random()*10);
         System.out.print(x+(","));
      if(x>=0 && x<=3)
       {
       c=c+1;
          } 
         else if(x>=4 && x<=6)
       {
      s=s+1;
      }
     else 
      {
       r=r+1;
       }
      i++;
      }
        System.out.println("\n\n   ##   FREQUENCY TABLE  ## ");
         System.out.println();
        System.out.println(" \t No of Student With Height ");
        System.out.println();
       System.out.println("    0-3 feet   "+c);
       System.out.println("    4-6 feet   "+s);
       System.out.println("   7-10 feet   "+r);
   }
 }
