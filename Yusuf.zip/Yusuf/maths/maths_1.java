package maths;
class maths_1 extends maths_2
{
    public static void main()
    {
     System.out.println(Math.floor(Math.min(13.4 , -12.3)));
         System.out.println(Math.max(-5,-5.4));
         System.out.println(Math.pow(Math.sqrt(625),0.5));
        double r=45; 
        System.out.println(r/=  10 + 5 * 2 + 3);
        int a=2,b=3,c=9;
        System.out.println(a*(++b)%c);
int x=75;
char ch=(char)x;
System.out.println(ch);
System.out.println((int)ch);
    }
}