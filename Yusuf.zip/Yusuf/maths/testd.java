package maths;
import java.util.*;
class testd
 {
    public static void main()
  {  
       int s=0,a,d,c;
     for(int i=1000;i<=9999;i++){
         d=i%100;
         a=i/100;
         s=d+a;
         c=(int)Math.pow(s,2);
      if(c==i){
      System.out.println(i+"is atech number");
      }
   }
 }
  public static void mass()
  {  
    Scanner sc=new Scanner(System.in);
     System.out.println("enter a number");
    int n=sc.nextInt();
    int i=1,s=0;
    while(i<n){
        s=i*(i+1);
        
        if(s==n){
            System.out.println(n+"is a pronic number");
            System.exit(0);  
        }
        i++;
 }
     System.out.println(n+"was not a prnic no");
}
 public static void mad()
  {  
      Scanner sc=new Scanner(System.in);
     System.out.println("enter a number");
    int n=sc.nextInt();
    int p=n,d,s=0,c=1;
    while(n!=0){
    d=n%10;
    n=n/10;
    s=s+d;
    c=c*d;
}
    if(s==c)
    System.out.println(p+"is a spy number");
    else
     System.out.println(p+"   is a NOT spy  Number ");
    
   }
   public static void maq()
  {  
      Scanner sc=new Scanner(System.in);
     System.out.println("enter a number");
    int n=sc.nextInt();
    int p=n,d,s=0,c=1;
    while(n!=0){
    d=n%10;
    n=n/10;
    s=s+d;

}
    if(p%s==0)
    System.out.println(p+"is a niven number");
    else
     System.out.println(p+"   is a NOT niven  Number ");
    
   }
   public static void ad()
  {  
      Scanner sc=new Scanner(System.in);
     System.out.println("enter a number");
    int o=sc.nextInt();
    switch(o){
        case 1:
        System.out.println("enter a number");
    int n=sc.nextInt();
    int i;
    for(i=2;i<n;i++){
   if(n%i==0)
       System.out.println(i);
    }
    break;
    case 2:
    System.out.println("enter a number");
    int f=sc.nextInt();
    int x=1,j;
    for(j=1;j<=f;j++){
        x=x*j;
    }
    System.out.println("The factorial of the number "+f+"! is: "+ x);
break;
default:
System.out.println("Wrong Input");
}
   }
   public static void gh()
  {  
      Scanner sc=new Scanner(System.in);
     System.out.println("enter a number");
    int n=sc.nextInt();
    int p=n,d,s=0,c=1,u=0;
    while(n!=0){
    d=n%10;
    n=n/10;
    s=s+d;
    c=c*d;
    u=s+c;
        
}
    if(u==p)
    System.out.println(p+"is a special number");
    else
     System.out.println(p+"   is a NOT special Number ");
   }
   public static void mlok()
  {  
Scanner sc=new Scanner(System.in);
     System.out.println("enter a number");
    int o=sc.nextInt();
    switch(o){
        case 1:
        System.out.println("enter a number");
    int n=sc.nextInt();
    int i,s=0,p=n;
   while(n!=0){
       i=n%10;
       n=n/10;
       s=(s*10)+i;
    }
    if(p==s)
              System.out.println(p+"  is a   palindrome no");
        else
           System.out.println(p+"  is not a   palindrome no");
    break;
    case 2:
    System.out.println("enter a number");
    int f=sc.nextInt();
    int j,c=0;//6
    for(j=1;j<f;j++){
        if(f%j==0)
        c=c+j;
    }
 if(c==f)
             System.out.println(f+" is perfect no");
             else
              System.out.println(f+"not a perfect no");
break;
default:
System.out.println("Wrong Input");
   }
   
 }
}

 
 
 
 
 /**
 
Question 9 (2013) [15]
Using the switch statement, write a menu driven program:
(i) To check and display whether a number input by the user is a composite
number or not (A number is said to be a composite, if it has one or more than
one factor excluding 1 and the number itself).
Example: 4, 6, 8, 9 ...
(ii) To find the smallest digit of an integer that is input.
Sample Input : 6524
Sample Output: Smallest digit is 2
For an incorrect choice, an appropriate error message should be displayed.
Question 5 (2013) [15]


Question 7: (2010) [15]
b) Automorphic number: An automorphic number is the number which is
contained in the last digit(s) of its square.
Example 25 is an automorphic number as its square is 625 and 25 is
present as the last two digits.

Question 8 (2009) [15]

(b) GCD (Greatest Common Divisor) of two integers is calculated by
continued division method. Divide the larger number by the smaller; the
remainder then divides the previous divisor. The process is repeated till the
remainder is zero. The divisor then results the GCD. [15]


  */
