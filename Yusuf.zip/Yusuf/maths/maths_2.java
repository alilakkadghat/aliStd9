 package maths;   
class maths_2 extends msth
{
    public static void main()
    {
 int p =100;
while(true)
{
if(p < 10)
break;
p=p -10;
}
System.out.println(++p);

    }
}