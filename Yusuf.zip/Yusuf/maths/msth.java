package maths; 
class msth extends lucky_boi 
{
    public static void main()
    {
        int s;
        for(s=0;s<=5;s++)
        {
            double x=Math.random();
             double y=x*6;
             System.out.println(y);
        }
    }
}

        