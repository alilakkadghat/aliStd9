package maths;

import java.util.*;
class area
{
    public static void main()
    {
      Scanner obj =new Scanner(System.in);
      System.out.println("enter your choice");
       System.out.println("1. area of rectangle");
       System.out.println("2. area of square");
       System.out.println("3. area of triangle");
   int a=obj.nextInt();
   int ar,l,b,s,bs,h;
   double art;
switch(a){
    case 1:
    System.out.println("enter the lenght");
    l=obj.nextInt();
    System.out.println(" enter the breath ");
    b=obj.nextInt();
    ar=l*b;
    System.out.println("area of rectangle ="+ar);
    break;
    case 2:
    System.out.println("enter the value of side");
    s=obj.nextInt();
    ar=s*s;
    System.out.println("area of square ="+ar);
    break;
    case 3:
    System.out.println("enter the base side ");
    bs=obj.nextInt();
    
    System.out.println("enter the height");
    h=obj.nextInt();
    
    art=0.5*bs*h;
    System.out.println("area of triangle ="+art);
    break;
    default:
    System.out.println("program not found");
}
}
}

  