import java.util.*;
class scanner_2$
{
public static void main ()
{
Scanner obj =new Scanner(System.in);
System.out.println("Enter your name");
String A=obj.next();
System.out.println("Enter the no of calls ");
int call=obj.nextInt();
int bill;
if (call >= 0 && call <= 100);
{  
 bill=call*1;
}
elseif (call >= 101 && call <= 200);
{
   bill=call*2; 
}
elseif (call>=201 && call<=300);
{
  bill=call*3;
}
else
{
   bill = call*5;
}
System.out.println("bill=RS."+bill);
}
}


 