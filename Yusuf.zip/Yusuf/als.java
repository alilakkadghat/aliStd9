 
import java.util.*;

public class als
{

  
    static public void main(String w)
    {
        int s;
        int b;
        String q;
        Scanner ob =  new  Scanner(System.in);
        System.out.println(" history marks ");
        s=ob.nextInt();
        System.out.println(" geog marks");
        b = ob.nextInt();
        int ss = s + b / 2;
        System.out.println(w);
        System.out.println("Average marks =" + ss);
        
    }
}
