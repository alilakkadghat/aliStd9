/*Using the switch statement, write a menu driven program to :
i) To find and display all the factors of a number input by the user
(including 1 and excluding number itself).
Example :
Sample Input : n = 15
Sample Output : 1, 3, 5
ii) To find display the factorial of a number input by the user (the
factorial of a non-negative integer n, denoted by n! is the product of all
integers less than or equal to n.
Example :
Sample Input : n = 5
Sample Output : 5! = 1 x 2 x 3 x 4 x 5 = 120
For an incorrect choice, an appropriate error message should be
displayed. */
import java.util.*;
class Numbers
{
public static void main()
{
Scanner sc = new Scanner(System.in);
System.out.println(" Menu:");
System.out.println("1. Factors of a number");
System.out.println("2. Factorial of a number");
int opt=sc.nextInt();
int n;
switch(opt)
{
case 1:
System.out.println("Enter an Integer number:");
n=sc.nextInt();
for(int i=1;i<n;i++)
{
if(n%i==0)
System.out.println(i);
}
break;
case 2:
System.out.println("Enter an Integer number:");
n=sc.nextInt();
int x=1;
for(int i=1;i<=n;i++)
{
x=x*i;
}
System.out.println("The factorial of the number "+n+"! is: "+ x);
break;
default:
System.out.println("Wrong Input");
}
}
}