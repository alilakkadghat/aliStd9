import java.util.Date;
import java.text.*;
public class realtime_date
{
    public static void main(){
      Date date =new Date();
   System.out.println(date.toString());
 System.out.println(date.getHours());
  SimpleDateFormat sdf=new SimpleDateFormat("E yyyy/MM/dd  HH-mm-ss");
  System.out.println(sdf.format(date));
    
}
        }