import java.util.*;
class array
{
    public static void main()
    {
    int[]mark={56,77,9,10,44,22,8,5};

    for(int i=0;i<=7;i++){
        if(mark[i]%2==0){
    System.out.println(mark[i]);
}
else{
    System.out.println("odd"+mark[i]);
}
}
}
}