
import java.util.*;
class case_switch 
{
    public static void main()
    {
        Scanner sc =new Scanner(System.in);
        months ob=new months();
        System.out.println("choose a alphabet between a to d");
            System.out.println("enter e to open months");
        char a=sc.next().charAt(0);
     switch(a)
     {
         case 'a':
         System.out.println("compile proced");
         break;
         case 'b':
         System.out.println("choose a new no");
         break;
         case 'c':
         System.out.println("diffrent option");
         break;
         case 'd':
         System.out.println("successful");
         break;
         case 'e':
         ob.main();
         break;
         default:
         System.out.println("Error!!!!!!");
        }
            
        System.out.println("Thank you");
    }
}