import java.util.*;
class calculATOR
{
public static void main()
{ 
 Scanner sc=new Scanner (System.in);
    System.out.println("Enter the 1st Number : ");
    int fst = sc.nextInt();
    System.out.println("Enter the 2nd Number : ");
    int snd =sc.nextInt();
    int sum = fst+snd;
    int product = fst*snd;
    int divident = fst/snd;
    System.out.println("the result are :");
    System.out.println("the sum of"+fst+" and "+snd+" is   "+sum);
   System.out.println("the product of"+fst+" and "+snd+" is "+product);
   System.out.println("the divident of"+fst+" and "+snd+" is "+divident);
}
}
