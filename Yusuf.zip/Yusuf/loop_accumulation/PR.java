//S=1/4+2/9+3/16----9/100

package loop_accumulation;

class PR 
{
 public static void main()
 {
 int i,a;
 double s=0.0;
 for(i=1;i<=9;i++)
 {
 a=i+1;
 s=s+(i*1.0/a*a);
 }
 System.out.println(s);
 }
} 