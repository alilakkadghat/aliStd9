package loop_accumulation;

import java.util.*;
class range
{
    public static void main()
    { 
        Scanner ob =new Scanner(System.in);
         System.out.println("Enter 1 to find value of z");
      System.out.println("Enter 2 to find fibonacci series"); 
         int p=ob.nextInt();
         int i;
         double z=0,y=5.5,x;
        switch(p){
            case 1:
        for(x=-10;x<=10;x=x+2)
        {
            z=(Math.pow(x,3)+(0.5*x))/y;
        }
        System.out.println("the value of z is:"+z);
        break;
        case 2:
        int a=0,b=1;
        System.out.println(a);
        System.out.println(b);
        int c=a+b;
        for(i=1;i<=8;i++)
        {
            System.out.println(c);
            a=b;
            b=c;
            c=a+b;
        }
        break;
        default:
        System.out.println("program not found ");
    }
}
}