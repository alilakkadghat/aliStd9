//2+22+222+2222+22222=? 
package loop_accumulation;
class Accu_5 
{
    public static void main()
    {
    int i;
    long s=0,d=0;
  for(i=0;i<=4;i=i+1)
  { 
    s=s+(Math.round(Math.pow(10,i)*2));//1+11+111+1111+111111
    //2+22+222+2222+22222
    d=s+d;
     System.out.println(""+s);
}
 System.out.println(""+d);
     // System.out.println(""+s);
}
}