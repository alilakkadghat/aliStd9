 //1+11+111+1111=?
 package loop_accumulation;
class Accu_4 extends Accu_5
{
    public static void main()
    {
    int i;
    long s=0,a=0;
  for(i=0;i<=4;i=i+1)
  { 
    s=s+(Math.round(Math.pow(10,i)));
   
    a=a+s;
}
 System.out.println(""+a);
      System.out.println(""+s);
}
}