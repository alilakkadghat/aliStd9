/*Write a program to accept a number and print sum of all even numbers from 2 till the
number entered and product of all odd number from 1 till the number entered.*/

package loop_accumulation;
import java.util.*;
class Accu_gg extends odd_even
{
    public static void main()
    {
        Scanner ob=new Scanner(System.in);
    System.out.println("Enter an integer");
    int a=ob.nextInt();
     int i,s=0,q=1;
  for(i=2;i<=a;i=i+2)
  {
s=s+i;
    }
    System.out.println(s);
     for(i=1;i<=a;i=i+2)
  {
q=q*i;
    } 
    System.out.println(""+q);
     
}
}