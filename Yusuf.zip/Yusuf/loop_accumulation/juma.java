package loop_accumulation;
import java.util.*;
class juma   
{
 public static void main() 
{
    int i;
    //Scanner ob=new Scanner(System.in);
    //System.out.println("Enter an integer");
    //int n=ob.nextInt();
    for(i=1;i<=10;i=i+1)
    {
        System.out.println(i*i*4);
    }
}
}