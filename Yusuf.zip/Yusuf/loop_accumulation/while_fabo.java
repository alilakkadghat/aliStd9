package loop_accumulation;
class while_fabo
{
    public static void main()
    {
        int i=1,a=0,b=1;
        System.out.println(a);
        System.out.println(b);
        int c=a+b;
        while(i<=18)
        {
            System.out.println(c);
           a=b;
           b=c;
           c=a+b;
           i++;
        }
    }
}

/*
 0
 1
 1
 2
 3
 5
 8
 13
 21
 34
*/