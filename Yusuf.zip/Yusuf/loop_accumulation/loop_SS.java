package loop_accumulation;
 
import java.util.*;
    class loop_SS
   {
    public static void main()
    {
        int i,his,geo,ss;
        String nm;
        Scanner ob= new Scanner(System.in);
        for(i=1;i<=10;i++)
    {
            System.out.println("enter students name, history and geography marks");
            nm=ob.nextLine();
            his=ob.nextInt();
            geo=ob.nextInt();
            ss=(his+geo)/2;
            if(ss>50)
    {
                System.out.println("Name:"+nm);
                System.out.println("Social studies marks:"+ss);
    }
    }
    }
    }
