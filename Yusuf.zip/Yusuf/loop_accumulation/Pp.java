package loop_accumulation;

class Pp
{
 public static void main()
 {
 int m=10,n=5;
 int i;
 for( i=1;i<=25;i=i+4);
 {
 System.out.println(i);
System.out.println(m+i);
System.out.println(m+n);
 }
}
}