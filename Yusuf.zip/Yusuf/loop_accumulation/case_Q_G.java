
package loop_accumulation;
import java.util.*;
class case_Q_G

{
    public static void main()
    {
      int i,c=0,x=1;
       Scanner obj=new Scanner(System.in);
       System.out.println("choose a no between 1 & 2 ");
       int n=obj.nextInt();
     switch(n)
     {
         case 1:
         for(i=1;i<=20;i++)
         {
          c=c+i;
          System.out.println(c);
          }
         break;
         case 2:
         for(i=2;i<=10;i=i+2)
         {
           x=x*i; 
           System.out.println(x);
          }
         break;
         default:
         System.out.println("Error!!!!!!");
        }
        System.out.println("Thank you");
    }
}