package loop_accumulation;
class loop_2
{
    public static void main(int n)
    {
     int i;
  for(i=5;i<=n;i=i+1)
  {
      System.out.println(i+(i*i));
    }
      System.out.println("thank you"+i);
}
}