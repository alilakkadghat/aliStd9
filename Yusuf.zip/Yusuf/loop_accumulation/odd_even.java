package loop_accumulation;
import java.util.*;
class odd_even   
{
 private static void mass() 
{
     Scanner ob =  new  Scanner(System.in);
        System.out.println("enter  A NUMBER");
      int n=ob.nextInt();
    int c=0, i,q=0;
    for(i=1;i<=n;i=i+1)
    {
     if(i%2==0)
     {c=c+i;
      
    }
}
System.out.println(c);
}
 public static void main()
       {
           odd_even.mass();
     Scanner ob =  new  Scanner(System.in);
        System.out.println("enter a number");
      int n=ob.nextInt();
    int  i,q=1;
    for(i=1;i<=n;i=i+1)
     {if(i%2==1)
     {
         q=q*i;
    
    }
}
       System.out.println(q);
}
}



    