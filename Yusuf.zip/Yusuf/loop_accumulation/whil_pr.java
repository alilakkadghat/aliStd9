package loop_accumulation;
class whil_pr
{
    public static void main()
    {
        int i=1,a;
         double s=0.0;
        while(i<=9)
        {
           a=i+1;
           s=s+(i*1.0/a*a);
             i=i+1;
        }
         System.out.println(s);
    }
}
