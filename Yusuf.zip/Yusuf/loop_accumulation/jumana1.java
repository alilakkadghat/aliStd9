 package loop_accumulation;
import java.util.*;
class jumana1 
{
 public static void main() 
{
    int i,c=0;
    //Scanner ob=new Scanner(System.in);
    //System.out.println("Enter an integer");
    //int n=ob.nextInt();
    for(i=2;i<=20;i=i+2)
    {
     c=c+i;
     System.out.println(c);
    }
}
}
    