package loop_accumulation;
import java.util.*;
class jumana2 
{
 public static void main() 
{
    double i,c=0;
    //Scanner ob=new Scanner(System.in);
    //System.out.println("Enter an integer");
    //int n=ob.nextInt();
    for(i=1;i<=20;i=i+1)
    {
     c=(i/(i+1));
     System.out.println(c);
    }
}
}
    