package loop_accumulation;
  //2+4+6+8.....20
class Accu_2 
{
    public static void main()
    {
     int x,s=0;
     System.out.println("     "+s);
  for(x=2;x<=20;x=x+2)
  {
      s=s+x;
      System.out.println(x);
    }
      System.out.println();
}
}
