package loop_accumulation;
import java.util.*;
class ju 
{
 public static void main() 
{
    int i;
    Scanner ob=new Scanner(System.in);
    System.out.println("Enter an integer");
    int n=ob.nextInt();
    for(i=2;i<=n;i=i+2)
    {
        System.out.println(i);
    }
}
}