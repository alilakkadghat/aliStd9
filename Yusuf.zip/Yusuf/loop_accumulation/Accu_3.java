package loop_accumulation;
class Accu_3
{
    public static void main()
    {
     int i,s=0;
  for(i=1;i<=2;i=i+1)
  {
    s=s+(i*(i+1));

    }
      System.out.println("thank you"+s);
}
}