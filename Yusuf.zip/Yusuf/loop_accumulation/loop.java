package loop_accumulation;
class loop
{
    public static void main()
    {
        int s;
        for(s=1;s<=5;s++)
        {
            System.out.println("you are a bot dodododo");
        }
    }
}

        