package loop_accumulation;
class fabonacci_series 
{
 public static void main() 
{
    int i;
    int a=0,b=1;
    System.out.println(a);
    System.out.println(b);
   
    int c=a+b;
    for(i=1;i<=8;i=i+1)
    {
     System.out.println(c);
     a=b;
     b=c;
     c=a+b;
    }
}
}