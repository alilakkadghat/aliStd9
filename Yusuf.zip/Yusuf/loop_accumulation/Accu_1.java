package loop_accumulation;
class Accu_1
{
    public static void main()
    {
     int x,s=0;
  for(x=1;x<=5;x=x+1)
  {
      s=s+x;
      System.out.println(x+"   "+s);
    }
      System.out.println("thank you"+s);
}
}