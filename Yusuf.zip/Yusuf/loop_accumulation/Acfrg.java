/*Write a program to accept a number and print sum of all even numbers from 2 till the
number entered and product of all odd number from 1 till the number entered.*/

package loop_accumulation;
import java.util.*;
class Acfrg extends Accu_gg 
{
    public static void main()
    {
        Scanner ob=new Scanner(System.in);
    System.out.println("Enter an integer");
    int a=ob.nextInt();
     int i,s=0,q=1;
  for(i=1;i<=a;i=i+1)
  {
      if(i%2==0)
s=s+i;
else
q=q*i;
    }
    System.out.println("sum of even no  " +s);
     
    System.out.println("product of odd no  " +q);
     
}
}