/*S=1/3+3/5+5/7----19/20*/
package loop_accumulation;
class pK
{
 public static void main()
 {
 int i;
 double s=0.0;
 for(i=1;i<=19;i++)
 {
 s=s+(i*1/i+2);

 }
 System.out.println(s);
 }
}