//S=3/4+4/9+5/16-----10/81

package loop_accumulation;
class PS
{
 public static void main()
 {
 int i,a;
 double s=0.0;
 for(i=3;i<=10;i++)
 {
 a=i-1;
 s=s+(i*1.0/a*a);
 }
 System.out.println(s);
 }
}