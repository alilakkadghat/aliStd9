package loop_accumulation;
class Tribonacci_series
{
 public static void main() 
{
    int i;
    int a=0,b=1,c=1;
    System.out.println(a);
    System.out.println(b);
    System.out.println(c);
    int d=a+b+c;
    for(i=1;i<=20;i=i+1)
    {
     System.out.println(d);
     a=b;
     b=c;
     c=d;
     d=a+b+c;
    }
}
}
