package loop_accumulation;
import java.util.*;
class jumana 
{
 public static void main() 
{
    int i,c=1;
    Scanner ob=new Scanner(System.in);
    System.out.println("Enter an integer");
    int n=ob.nextInt();
    for(i=1;i<=n;i=i+1)
    {
     c=c*i;
     System.out.println(c);
    }
}
}
    