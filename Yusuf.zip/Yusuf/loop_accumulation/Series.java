/*Write a menu driven program to perform the following : (Use switch – case
statement)
a) To print the series 0, 3, 8, 15, 24.....n terms (value of „n‟ is to be an
input by the
user.)
b) To find the sum of the series given below :
S = 1/2 + 3/4 + 5/6 + 7/8 ---------- 19/20. */
package loop_accumulation;
import java.util.*;
class Series
{
public static void main()
{
Scanner sc = new Scanner(System.in);
System.out.println("Enter 1 for series,2 for sum");
int n = sc.nextInt();
switch(n)
{
case 1:
System.out.println("enter a number");
int a = sc.nextInt();
int c;
for(int i = 1;i<=a;i++)
{
c=(i*i)-1;
System.out.print(c);
}
break;
case 2:
double s =0;
for(double j=1;j<=19;j=j+2)
{
s = s+(j/(j+1));
}
System.out.println(s);
break;
default:
System.out.println("wrngnum");
}
}
}