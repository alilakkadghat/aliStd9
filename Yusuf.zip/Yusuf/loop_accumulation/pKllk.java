package loop_accumulation;
import java.util.*;
class pKllk
{
 public static void main()
 {
 int i,j;
Scanner sc =new Scanner (System.in);
int n=sc.nextInt();
 for(i=1;i<=n;i++)
 {
 j=i*i;
 System.out.println(j);
 }
 
 }
}
