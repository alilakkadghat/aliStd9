package loop_accumulation;
import java.util.*;
class jumanhg
{
 public static void main() 
{
    double i,c=0;
   
    for(i=1;i<=10;i=i+1)
    {
     c=c+(i/(i+1));
     
    }
        System.out.println(c);
}
}
    