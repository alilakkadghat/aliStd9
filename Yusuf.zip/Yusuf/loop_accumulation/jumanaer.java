package loop_accumulation;
import java.util.*;
class jumanaer 
{
 public static void main() 
{
    double i,c=0;
    Scanner ob=new Scanner(System.in);
    System.out.println("Enter an integer");
    int n=ob.nextInt();
    for(i=1;i<=n;i=i+1)
    {
     c=c+(1/i);
     //System.out.println(c);
    }
    System.out.println("kj"+c);
}
}
    