class if$
{
    public static void main(int c)
    {
        double bill = 0;
        if (c >= 0 && c <= 100)
        {
            bill = c * 1;
        }
        else if (c > 100 && c <= 200)
        {
            bill = (100*1) + ((c-100)*2);
        }
    System.out.println("bill = "+bill);
}
}   